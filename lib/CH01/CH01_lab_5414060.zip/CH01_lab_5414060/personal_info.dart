void main() {
  print("\nName : Suhwan Kim");
  print("ID : 5414060");
  print("Phone : 010-5493-3582");
  print("Department: Computer engineering");
  print("Grade : senior");
}
