import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class SimpleStatefulWidget extends StatefulWidget {
  const SimpleStatefulWidget({super.key});

  @override
  State<SimpleStatefulWidget> createState() => _SimpleStatefulWidgetState();
}

class _SimpleStatefulWidgetState extends State<SimpleStatefulWidget> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

void main() => runApp(SimpleStatefulWidget());

class SimpleStatelessWidget extends StatelessWidget {
  const SimpleStatelessWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
